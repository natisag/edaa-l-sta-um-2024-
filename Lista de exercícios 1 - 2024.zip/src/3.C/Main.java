public class Main {
    public static void main(String[] args) {
        // Criando instâncias de Professor, Disciplina, Aluno e Universidade
        Professor prof1 = new Professor("João", "Matemática");
        Disciplina disciplina1 = new Disciplina("Cálculo", prof1);

        Aluno aluno1 = new Aluno("Maria", 20);
        Aluno aluno2 = new Aluno("Pedro", 22);

        Universidade universidade = new Universidade("Universidade XYZ");
        universidade.adicionarAluno(aluno1);
        universidade.adicionarAluno(aluno2);

        // Imprimindo os dados dos alunos da universidade
        universidade.listarAlunos();
    }
}
